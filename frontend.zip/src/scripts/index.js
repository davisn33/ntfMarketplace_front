const Collectibles = require("./models/collectibles");
const Buckets = require("./buckets");
const utils = require("./utils");

module.exports ={
    Collectibles,
    Buckets,
    utils
}